#include "Item.h"

Item::Item() : cashinhand(100) // default constructor
{
}

// Member function sell item
void Item::sellitem()
{
    std::cout << "Enter Product Type Burger 1 or Pizza 2" << std::endl;
    int atype;
    int point;
    std::cin >> point;
    try{
        
        if(point != 1 && point != 2){
            throw std::invalid_argument("Invalued value of product type");
        }
        
    }
    catch(std::exception &e)
    {
        std::cout << e.what() << std::endl;
        std::cout<<"new value of product type should be Burger 1 or Pizza 2"<<std::endl;
        
    }
    char c;
    try{
        std::cin>>c;
        if(c >= 'a' && c != 'z'){
            throw std::invalid_argument("Invalued value");
        }
        
    }
    catch(std::exception &e)
    {
        std::cout << e.what() << std::endl;
        std::cout<<"new value of product type Burger 1 or Pizza 2"<<std::endl;
        std::cin >> atype;
    }
   
    switch (atype)
    {
    case 1:
        type = product_type::Burger;
        costperitem = 10;
        break;
    case 2:
        type = product_type::Pizza;
        costperitem = 20;
        break;
    }
    std::cout << "Number of items to be purchased" << std::endl;
    std::cin >> numberofitems;
    int balance;

    // exception handling
    try
    {
        balance = cashinhand;
        if (balance < 0)
        {
            throw std::invalid_argument("Insufficient Balance");
        }
        cashinhand = cashinhand - (costperitem * numberofitems);
        if (cashinhand < 0 )
        {
            throw std::invalid_argument("Insufficient Cash in Hand");
        }
        std::cout << "get cash in hand"
                  << " " << cashinhand << std::endl;
    }
    catch (std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}