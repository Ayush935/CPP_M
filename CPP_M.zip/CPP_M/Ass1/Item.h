#ifndef ITEM_H
#define ITEM_H

#include <iostream>

enum product_type // ennumeration
{
    Burger = 1,
    Pizza // burger 1    pizza 2
};

class Item
{
    enum product_type type; // enummeration
    int numberofitems;      // data members
    int cashinhand;
    int costperitem;

public:
    Item();          // default constructor
    void sellitem(); // member function

    int getCashinhand() const { return cashinhand; }
};

#endif // ITEM_H
