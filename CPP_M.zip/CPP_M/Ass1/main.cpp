#include "Item.h"

int main()
{
    Item p; // object created
    p.sellitem();
    int count = 1;

    // keep calling when2

    
    while (p.getCashinhand() > 0)
    {
        p.sellitem();
        count++;
    }
    std::cout << "number of times sellitem call" << " "<< count << std::endl;
}