#include "Player.h"

int Player::num = 100;

Player::Player() : Playerage(22), Numberofmatchesplayed(2), Playerrank(3)
{
    num++; // default constructor
    PlayerId = num;
    Playername = new char[10];
    strcpy(Playername, "Bob");
    Score = new int[3];
    Score[0] = 5;
    Score[1] = 10;
    Score[2] = 15;
}

double const Player::Calculateaveragescore() // function for calculate average score
{
    float sum = 0;
    for (int i = 0; i < 3; i++)
    {
        sum = sum + Score[i];
    }
    double average_Score = (sum / 3.00);
    return average_Score;
}

bool Player::operator<(Player &other) // operator overloading for <
{
    return (Calculateaveragescore() < other.Calculateaveragescore());
}

bool Player::operator==(const Player &other) // operator overloading for ==
{

    return (Numberofmatchesplayed == other.Numberofmatchesplayed);
}

double Player::operator+(Player &other) // operator overloading for +
{
    return Calculateaveragescore() + other.Calculateaveragescore();
}

std::ostream &operator<<(std::ostream &out, Player &other) // operator overloading for <<
{
    out << "Player ID is            "
        << " " << other.PlayerId << "\n";
    out << "Player Name is          "
        << " " << other.Playername << "\n";
    out << "Player Age is           "
        << " " << other.Playerage << "\n";
    out << "Number of matches played"
        << " " << other.Numberofmatchesplayed << "\n";
    out << "Player Rank             "
        << " " << other.Playerrank << "\n";
    out << "Score" << std::endl;
    for (int i = 0; i < 3; i++)
    {
        out << other.Score[i] << " ";
    }
    out << "\n";
    return out;
}

Player::~Player() // destructor called
{
    delete[] Playername;
    delete[] Score;
}