#include "Parking_Bill.h"

void total_parking_charges(Parking_Bill bill[])   //total parking charges
{
    int sum = 0;
    for (int i = 0; i < 3; i++)
    {
        sum = sum + bill[i].calculateBill();
    }
    std::cout << "Total charges " << sum << "\n";
}

void search(char a[10], Parking_Bill bill[])    //total bill
{
    try
    {
        for (int i = 0; i < 3; i++)
        {
            if (strcmp(bill[i].getparkedVehicle(), a))
            {
                std::cout << "Found the vehicle" << std::endl;
            }
        }
        throw std::invalid_argument("Vehicle not found");
    }
    catch (std::exception &e)
    {
        std::cout << e.what() << "\n";
    }
}

int main()
{
    vehicle objects[3];
    for (int i = 0; i < 3; i++)
    {
        std::cin >> objects[i];
    }
    Parking_Bill bill[3];

    for (int i = 0; i < 3; i++)
    {
        bill[i].setParkedVehicle(objects[i]);
    }

    int sum = 0;
    for (int i = 0; i < 3; i++)
    {
        std::cout << "Bill for vehicle"
                  << " " << i << std::endl;
        std::cout << bill[i].calculateBill();
        std::cout << bill[i];
    }

    total_parking_charges(bill);
    std::cout << "Enter the vehicle number to search" << std::endl;
    char name[10];
    std::cin >> name;
    search(name, bill);

    std::cout << "total number of vehicles"
              << "\n";
    std::cout << bill[2].gettotalVehicles() << "\n";
}