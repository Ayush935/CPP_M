#ifndef PARKING_BILL_H
#define PARKING_BILL_H

#include "vehicle.h"

class Parking_Bill
{
   int billnumber; // data members
   vehicle parked_vehicle;
   float parking_charges_amt;
   int *parking_charges_2wheelers;
   int *parking_charges_4wheelers;

public:
   Parking_Bill();
   Parking_Bill(int, const char *, enum vehicle_type, int, int, float, int *, int *);

   int getBillnumber() const { return billnumber; } // getter setter
   void setBillnumber(int billnumber_) { billnumber = billnumber_; }

   float parkingChargesAmt() const { return parking_charges_amt; }
   void setParkingChargesAmt(float parkingChargesAmt) { parking_charges_amt = parkingChargesAmt; }

   int *parkingCharges2wheelers() const { return parking_charges_2wheelers; }
   void setParkingCharges2wheelers(int *parkingCharges2wheelers) { parking_charges_2wheelers = parkingCharges2wheelers; }

   int *parkingCharges4wheelers() const { return parking_charges_4wheelers; }
   void setParkingCharges4wheelers(int *parkingCharges4wheelers) { parking_charges_4wheelers = parkingCharges4wheelers; }

   friend std::ostream &operator<<(std::ostream &out, Parking_Bill &other); // operator overloading for <<
   friend std::istream &operator>>(std::istream &in, Parking_Bill &other);  // operator overloading for >>

   int calculateBill();

   char *getparkedVehicle() const { return parked_vehicle.getvehicleNum(); }
   void setParkedVehicle(const vehicle &parkedVehicle) { parked_vehicle = parkedVehicle; }

   int gettotalVehicles() const { return parked_vehicle.gettotalVehicles(); }

   void total_parking_charges(Parking_Bill bill[]);

  
   // void search(char a[10]);
};

#endif // PARKING_BILL_H
