#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <cstring>

enum vehicle_type // enummerations
{
    TWO_WHEELERS = 0,
    FOUR_WHEELERS
};

class vehicle // data members
{
    char *vehicle_num;
    enum vehicle_type type;
    int parking_hrs;
    int parkingID;
    int total_vehicles;
    static int num;

public:
    vehicle();
    vehicle(const char *name, enum vehicle_type atype, int hrs, int id);
    int getparkingHrs() const { return parking_hrs; }
    void setParkingHrs(int parkingHrs) { parking_hrs = parkingHrs; }

    int getParkingID() const { return parkingID; }
    void setParkingID(int parkingID_) { parkingID = parkingID_; }

    int gettotalVehicles() const { return total_vehicles; }
    void setTotalVehicles(int totalVehicles) { total_vehicles = totalVehicles; }

    friend std::ostream &operator<<(std::ostream &out, vehicle &other); // operator overloading for <<
    friend std::istream &operator>>(std::istream &in, vehicle &other);  // operator overloading for >>

    char *getvehicleNum() const { return vehicle_num; }
    void setVehicleNum(char *vehicleNum) { vehicle_num = vehicleNum; }

    void static showNumberof_vehicles();

    enum vehicle_type getType() const { return type; }
    void setType(const enum vehicle_type &type_) { type = type_; }
};

#endif // VEHICLE_H
