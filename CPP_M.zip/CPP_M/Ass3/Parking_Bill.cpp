#include "Parking_Bill.h"

Parking_Bill::Parking_Bill() : billnumber(100), parked_vehicle(), parking_charges_amt(100) // default constructor
{
}
Parking_Bill::Parking_Bill(int number, const char *name, enum vehicle_type atype, int hrs, int id, float amt, int *twowhel, int *forwhel) : billnumber(number), parked_vehicle(name, atype, hrs, id), parking_charges_amt(amt) // para constructor
{
    parking_charges_2wheelers = new int[3];
    parking_charges_4wheelers = new int[3];
    for (int i = 0; i < 3; i++)
    {
        parking_charges_2wheelers[i] = twowhel[i];
        parking_charges_4wheelers[i] = forwhel[i];
    }
}

std::ostream &operator<<(std::ostream &out, Parking_Bill &other)
{
    out << "Bill number is "
        << "\n";
    out << other.billnumber << "\n";
    out << other.parked_vehicle << "\n";
    out << "Parking amount charges"
        << "\n";
    out << other.parking_charges_amt << "\n";
    out << "parking charges teo wheeler"
        << "\n";
    for (int i = 0; i < 3; i++)
    {
        out << other.parking_charges_2wheelers[i] << "\n";
    }
    out << "parking charges teo wheeler"
        << "\n";
    for (int i = 0; i < 3; i++)
    {
        out << other.parking_charges_4wheelers[i] << "\n";
    }
    return out;
}
std::istream &operator>>(std::istream &in, Parking_Bill &other)
{
    std::cout << "Enter bill number"
              << "\n";
    in >> other.billnumber;
    in >> other.parked_vehicle;
    std::cout << "parking charges amount"
              << "\n";
    in >> other.parking_charges_amt;
    std::cout << "parking amount for 2 wheelers";
    for (int i = 0; i < 3; i++)
    {
        in >> other.parking_charges_2wheelers[i];
    }
    std::cout << "parking amount for 4 wheelers";
    for (int i = 0; i < 3; i++)
    {
        in >> other.parking_charges_4wheelers[i];
    }
    return in;
}

int Parking_Bill::calculateBill()
{
    int bill = 0;
    int hrs = parked_vehicle.getparkingHrs() % 3;
    if (parked_vehicle.getType() == vehicle_type::FOUR_WHEELERS)
    {
        if (parked_vehicle.getparkingHrs() % 3 == 0)
        {
            for (int i = 0; i < parked_vehicle.getparkingHrs() / 3; i++)
            {
                bill = bill + 3 * parking_charges_4wheelers[i];
            }
        }
        else
        {
            for (int i = 0; i < parked_vehicle.getparkingHrs() / 3; i++)
            {
                bill = bill + 3 * parking_charges_4wheelers[i];
            }
            bill = bill + (parked_vehicle.getparkingHrs() % 3) * parking_charges_4wheelers[hrs + 1];
        }
    }
    else
    {
        if (parked_vehicle.getparkingHrs() % 3 == 0)
        {
            for (int i = 0; i < parked_vehicle.getparkingHrs() / 3; i++)
            {
                bill = bill + 3 * parking_charges_2wheelers[i];
            }
        }
        else
        {
            for (int i = 0; i < parked_vehicle.getparkingHrs() / 3; i++)
            {
                bill = bill + 3 * parking_charges_2wheelers[i];
            }
            bill = bill + (parked_vehicle.getparkingHrs() % 3) * parking_charges_2wheelers[hrs + 1];
        }
    }

    return bill;
}


