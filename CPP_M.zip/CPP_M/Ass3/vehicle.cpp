#include "vehicle.h"

int vehicle::num = 0;

vehicle::vehicle() : parking_hrs(5), type(vehicle_type::FOUR_WHEELERS), parkingID(3242)
{
    vehicle_num = new char[10];
    strcpy(vehicle_num, "MH3214");
    num++;
    total_vehicles = num;
}

vehicle::vehicle(const char *name, enum vehicle_type atype, int hrs, int id) : type(atype), parking_hrs(hrs), parkingID(id)
{
    vehicle_num = new char[strlen(name) + 1];
    strcpy(vehicle_num, name);
}

std::istream &operator>>(std::istream &in, vehicle &other)
{
    std::cout << "Enter Vehicle Num"
              << "\n";
    in >> other.vehicle_num;
    std::cout << "\n";
    std::cout << "Enter vehicle type"
              << "\n";
    char type_name[10];
    std::cin >> type_name;
    int type_num = 1;
    if (strcmp(type_name, "TWOWH"))
    {
        type_num = 0;
    }
    // if(strcmp(type_name,"TWOWH")){
    //    type_num
    // }
    switch (type_num)
    {
    case 0:
        other.type = vehicle_type::TWO_WHEELERS;
        break;
    case 1:
        other.type = vehicle_type::FOUR_WHEELERS;
        break;
    }
    std::cout << "Enter parking hrs"
              << "\n";
    in >> other.parking_hrs;
    std::cout << "Enter parking ID"
              << "\n";
    in >> other.parkingID;

    return in;
}

std::ostream &operator<<(std::ostream &out, vehicle &other)
{
    out << "vehicle num" << other.vehicle_num;
    out << "Vehicle type" << other.type;
    out << "parking hrs" << other.parking_hrs;
    out << "parking ID" << other.parkingID;
    out << "\n";
    return out;
}

void vehicle::showNumberof_vehicles()
{
    std::cout << "Number of total vehicles" << std::endl;
    std::cout << num << std::endl;
}

